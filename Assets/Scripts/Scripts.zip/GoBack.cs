using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GoBack : MonoBehaviour
{
    public void Loadintro(string minigameName)
    {
        if (GameManager.Instance.DialogueEnabled)
        {
            SceneManager.LoadScene(minigameName + " Dialogue");
        }
        else
        {
            SceneManager.LoadScene(minigameName + " Intro");
        }   
        
    }

    public void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }

    public void LoadGame1()
    {
        if (Minigame1Manager.UnansweredQuestions.Count == 0)
        {
            SceneManager.LoadScene("Minigame 1 End");

            return;
        }
        else
        {
            SceneManager.LoadScene("Minigame 1");
        }
    }

    public void LoadGame2()
    {
        if (Minigame2Manager.UnansweredQuestions.Count == 0)
        {
            SceneManager.LoadScene("Minigame 2 End");
            return;
        }
        else
        {
            SceneManager.LoadScene("Minigame 2");
        }
    }

    public void BeginGame3()
    {
        var activeCareer = ActiveCareerController.ActiveCareer;

        SceneManager.LoadScene(activeCareer.Minigame3Scene);
        //Screen.orientation = ScreenOrientation.LandscapeLeft;
        
    }

    public void LoadGame3()
    {
        var activeCareer = ActiveCareerController.ActiveCareer;

        if (Minigame3Manager.UnansweredQuestions.Count == 0)
        {
            SceneManager.LoadScene("Minigame 3 End");
            return;
        }
        else
        {
            SceneManager.LoadScene(activeCareer.Minigame3Scene);
        }
    }

    public void LoadMenu()
    {
        var activeCareer = ActiveCareerController.ActiveCareer;

        if (GameManager.Instance.ScoreEnabled)
        {
            if (ScoreManager.Instance != null)
            {
                ScoreManager.Instance.ResetScore();
            }           
        }

        if (GameManager.Instance.WorldEnabled)
        {
            SceneManager.LoadScene(activeCareer.ExplorerWorld);
        }
        else
        {
            SceneManager.LoadScene("Testing");
        }
        Screen.orientation = ScreenOrientation.Portrait;
    }

    public void ExitGame()
    {
        Application.Quit();
    }

    
}
